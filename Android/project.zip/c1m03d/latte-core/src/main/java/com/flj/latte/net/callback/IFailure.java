package com.flj.latte.net.callback;

/**
 * Created by 傅令杰 on 2017/4/2
 */

public interface IFailure {

    void onFailure();
}
