package com.flj.latte.util.timer;

/**
 * Created by 傅令杰 on 2017/4/22
 */

public interface ITimerListener {
    void onTimer();
}
