package com.flj.latte.wechat.callbacks;

/**
 * Created by 傅令杰 on 2017/4/25
 */

public interface IWeChatSignInCallback {
    void onSignInSuccess(String userInfo);
}
