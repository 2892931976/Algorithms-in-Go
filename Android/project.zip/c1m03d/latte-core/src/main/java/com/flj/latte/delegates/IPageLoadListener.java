package com.flj.latte.delegates;

/**
 * Created by 傅令杰
 */

public interface IPageLoadListener {

    void onLoadStart();

    void onLoadEnd();
}
