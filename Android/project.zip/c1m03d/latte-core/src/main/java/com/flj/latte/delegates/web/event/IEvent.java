package com.flj.latte.delegates.web.event;

/**
 * Created by 傅令杰
 */

public interface IEvent {

    String execute(String params);
}
