package com.flj.latte.app;

/**
 * Created by 傅令杰 on 2017/4/22
 */

public interface IUserChecker {

    void onSignIn();

    void onNotSignIn();
}
