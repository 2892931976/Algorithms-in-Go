package com.flj.latte.util.callback;

/**
 * Created by 傅令杰
 */

public enum CallbackType {
    ON_CROP,
    TAG_OPEN_PUSH,
    TAG_STOP_PUSH,
    ON_SCAN
}
