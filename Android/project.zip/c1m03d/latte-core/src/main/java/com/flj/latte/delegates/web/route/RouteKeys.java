package com.flj.latte.delegates.web.route;

/**
 * Created by 傅令杰
 */

public enum RouteKeys {
    /**
     * web页面跳转必须传递的参数
     */
    URL
}
