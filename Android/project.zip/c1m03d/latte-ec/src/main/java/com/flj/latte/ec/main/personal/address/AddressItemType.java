package com.flj.latte.ec.main.personal.address;

/**
 * Created by 傅令杰
 */

public class AddressItemType {
    static final int ITEM_ADDRESS = 40;
}
