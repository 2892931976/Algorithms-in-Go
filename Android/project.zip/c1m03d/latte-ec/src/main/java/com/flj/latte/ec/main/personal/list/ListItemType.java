package com.flj.latte.ec.main.personal.list;

/**
 * Created by 傅令杰
 */

public class ListItemType {

    public static final int ITEM_NORMAL = 20;
    public static final int ITEM_AVATAR = 21;
    public static final int ITEM_SWITCH = 22;
}
