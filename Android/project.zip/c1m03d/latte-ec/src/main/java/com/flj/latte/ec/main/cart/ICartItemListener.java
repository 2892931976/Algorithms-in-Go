package com.flj.latte.ec.main.cart;

/**
 * Created by 傅令杰
 */

public interface ICartItemListener {
    void onItemClick(double itemTotalPrice);
}
