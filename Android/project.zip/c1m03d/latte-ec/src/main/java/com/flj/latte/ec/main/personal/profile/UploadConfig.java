package com.flj.latte.ec.main.personal.profile;

/**
 * Created by 傅令杰
 */

public class UploadConfig {

    public static final String API_HOST = "你的服务器域名";
    public static final String UPLOAD_IMG = API_HOST + "你的上传地址";
}
