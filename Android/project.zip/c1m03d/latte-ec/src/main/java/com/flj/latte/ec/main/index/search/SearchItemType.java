package com.flj.latte.ec.main.index.search;

/**
 * Created by 傅令杰
 */

public class SearchItemType {

    static final int ITEM_SEARCH = 50;
}
