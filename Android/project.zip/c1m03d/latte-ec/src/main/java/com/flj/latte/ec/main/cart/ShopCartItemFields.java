package com.flj.latte.ec.main.cart;

enum ShopCartItemFields {
    TITLE,
    DESC,
    COUNT,
    PRICE,
    IS_SELECTED,
    POSITION
}