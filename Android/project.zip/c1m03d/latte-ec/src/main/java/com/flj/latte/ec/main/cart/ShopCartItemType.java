package com.flj.latte.ec.main.cart;

/**
 * Created by 傅令杰
 */

class ShopCartItemType {

    static final int SHOP_CART_ITEM = 6;
}
