package com.flj.latte.ec.main.personal.order;

/**
 * Created by 傅令杰
 */

public enum OrderItemFields {
    PRICE,
    TIME
}
