package com.flj.latte.ec.main.personal.address;

/**
 * Created by 傅令杰
 */

public enum AddressItemFields {
    PHONE,
    ADDRESS
}
