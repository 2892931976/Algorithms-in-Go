package com.flj.latte.ec.sign;

/**
 * Created by 傅令杰 on 2017/4/22
 */

public interface ISignListener {

    void onSignInSuccess();

    void onSignUpSuccess();
}
