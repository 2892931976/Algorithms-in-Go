package com.flj.latte.ui.image;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

/**
 * Created by 傅令杰
 */
@GlideModule
public class LatteGlideModel extends AppGlideModule {
}
