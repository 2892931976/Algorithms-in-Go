package com.flj.latte.ui.launcher;

/**
 * Created by 傅令杰 on 2017/4/22
 */

public enum OnLauncherFinishTag {
    SIGNED,
    NOT_SIGNED
}
