package com.flj.latte.ui.recycler;

/**
 * Created by 傅令杰
 */

public enum MultipleFields {
    ITEM_TYPE,
    TITLE,
    TEXT,
    IMAGE_URL,
    BANNERS,
    SPAN_SIZE,
    ID,
    NAME,
    TAG
}
