package com.flj.latte.ui.launcher;

/**
 * Created by 傅令杰 on 2017/4/22
 */

public enum ScrollLauncherTag {
    HAS_FIRST_LAUNCHER_APP
}
